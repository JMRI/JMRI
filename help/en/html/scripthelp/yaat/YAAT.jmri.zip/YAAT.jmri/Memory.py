# Memory Extension
# Copy_memory from <name> to <name>
# If_memory <name> is <eq | ne | lt | gt | le | ge> to <value>
# Set_memory <name> to <value>

def doCopy_memory(self, action):
    print '++ ext = Copy_memory: {}'.format(action)

def doIf_memory(self, action):
    print '++ ext = If_memory: {}'.format(action)

def doSet_memory(self, action):
    act, memoryName, memoryValue = action
    memory = memories.getMemory(memoryName)
    if memory is None:
        self.displayMessage('{} - Memory {} not found'.format(self.threadName, memoryName))
        return
    memory.setValue(memoryValue)

def compileCopy_memory(self, line):
    self.actionTokens.append(['Copy_memory'])

def compileIf_memory(self, line):
    self.actionTokens.append(['If_memory'])

def compileSet_memory(self, line):
    # Set_memory <name> to <value>
    if logLevel > 2: print '  {} - {}'.format(self.threadName, line)
    pattern = re.compile('\s*Set_memory\s+(.+\S)\s+to\s+(.+\S)')
    result = re.findall(pattern, line)
    print result
    if logLevel > 3: print '    {} - result = {}'.format(self.threadName, result)
    if len(result) == 0 or len(result[0]) != 2:
        self.compileMessages.append('{} - Syntax error at line {}: {}'.format(self.threadName, self.lineNumber, line))
        return
    memoryName, memoryValue = result[0]
    memory = memories.getMemory(memoryName)
    if memory is None:
        self.compileMessages.append('{} - Memory error at line {}: memory "{}" not found'.format(self.threadName, self.lineNumber, memoryName))
        return
    self.actionTokens.append(['Set_memory', memoryName, memoryValue])
